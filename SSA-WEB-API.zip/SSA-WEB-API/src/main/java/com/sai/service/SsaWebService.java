package com.sai.service;

import com.sai.binding.SsaWebRequest;
import com.sai.binding.SsaWebResponse;

public interface SsaWebService {
	
	public SsaWebResponse getCitizenInfo(SsaWebRequest request);

}
