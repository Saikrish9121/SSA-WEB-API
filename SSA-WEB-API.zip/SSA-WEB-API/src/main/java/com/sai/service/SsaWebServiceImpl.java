package com.sai.service;

import org.springframework.stereotype.Service;

import com.sai.binding.SsaWebRequest;
import com.sai.binding.SsaWebResponse;

@Service
public class SsaWebServiceImpl implements SsaWebService{

	@Override
	public SsaWebResponse getCitizenInfo(SsaWebRequest request) {
		
		SsaWebResponse response=new SsaWebResponse();
		Long ssn = request.getSsn();
		String ssnStr = String.valueOf(ssn);
		response.setSsn(ssn);
		
		if(ssnStr.startsWith("1")) {
			response.setStateName("Texas");
		}else if(ssnStr.startsWith("2")) {
			response.setStateName("Missouri");
		}else if(ssnStr.startsWith("3")) {
			response.setStateName("Lowa");
		}else if(ssnStr.startsWith("4")) {
			response.setStateName("Rhode Island");
		}else if(ssnStr.startsWith("5")) {
			response.setStateName("Minnestoa");
		}else if(ssnStr.startsWith("6")) {
			response.setStateName("Illinois");
		}else if(ssnStr.startsWith("7")) {
			response.setStateName("Milwaukee");
		}else if(ssnStr.startsWith("8")) {
			response.setStateName("Indiana");
		}else if(ssnStr.startsWith("9")) {
			response.setStateName("Ohio");
		}
		return response;
	}


}
