package com.sai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsaWebApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
